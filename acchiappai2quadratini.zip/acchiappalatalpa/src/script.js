//class Walker -> progetto da visualizzare
class Walker {
  constructor(elemParameter) {
    this.elem = elemParameter;
    this.x = 1;
    this.y = 1;
  } //costruttore setta posizione iniziale del quadrato
  //walker.step(); //sposta l'oggetto walker
  step() {
    let incrementox;
    let incrementoy;
    incrementox = Math.floor((Math.random()* 3) - 1);
    incrementoy = Math.floor((Math.random()* 3) - 1);
    this.y = this.y + incrementoy;
    this.x = this.x + incrementox;
    if (this.y < 0) {
      this.y = this.y + 350;
    }
    if (this.x < 0) {
      this.x = this.x + 350;
    }
    if (this.y > 350) {
      this.y = this.y - 350;
    }
    if (this.x > 350) {
      this.x = this.x - 350;
    }
  }
  // walker.display(); //aggiorna la posizione di walker
  display() {
    this.elem.style.top = this.y + "px";
    this.elem.style.left = this.x + "px";
  }
  // walker1.step(); //sposta l'oggetto walker1
  //walker1.display(); //aggiorna la posizione di walker1 
  walkerUpdate() {
    this.step();
    this.display();
  }
  walkerReset() {
    this.x = 1;
    this.y = 1;
    this.display();
  }
}

function frame() {
  /*
 
 
  */
  walker.walkerUpdate();
  walker1.walkerUpdate();
}

function myMove() {
  let interval = 10; //imposta l'intervallo
  id = setInterval(frame, interval); //imposta il timer con cui chiama la funzione frame()
  }

function myStop() {
  clearInterval(id);
  walker.walkerReset(); //riporta l'oggetto walker alla posizione 1px, 1px
  walker1.walkerReset(); //riporta l'oggetto walker1 alla posizione 1px, 1px
}

let walker = new Walker(document.getElementById("animate")); //crea un nuovo oggetto (walker) appartenente alla classe Walker

let walker1 = new Walker(document.getElementById("animate1")); //crea un nuovo oggetto (walker1) appartenente alla classe Walker




//questa funzione fa muovere casualmente il quadrato rosso dopo esser stato premuto 1 volta col mouse
/*function myMove(){
  let id = null;
  const elem = document.getElementById("animate");   
  pos=0; 
  clearInterval(id);
  id = setInterval(frame, 500);
  function frame() {
    elem.style.top = Math.random()*350 +"px";
    elem.style.left = Math.random()*350 +"px";
  }  
}

//questa funzione ad ora rimette il quadrato rosso nella posizione iniziale per 1 frame, ma non arresta ancora il movimento casuale della funzione myMove
function Pause() {
  let id = null;
  const elem = document.getElementById("animate");   
  pos=0;  
  elem.style.top = pos + "px"; 
  elem.style.left = pos + "px"; 
  clearInterval(id);
  }

//questa funzione calcola il punteggio ottenuto dal giocatore
function myPoints(){
  // Get the value of the input field with id="numb"
  let x = 0;
  // If x is Not a Number or less than one or greater than 10
  let text;
  text = "x";
  x++;
 
  document.getElementById("demo").innerHTML = text;
}

<p>Premi il pulsante Reset per sospendere il gioco.</p>
<p><button onclick="Pause()">Reset</button></p> 
<div id ="container">
  <div id ="animate" onclick="myMove()"></div>
</div>
<div id ="animate" onclick="myPoints()"></div>
<p id="demo"></p>*/