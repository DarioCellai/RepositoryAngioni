//questa funzione fa muovere casualmente il quadrato rosso dopo esser stato premuto 1 volta col mouse
function myMove(){
  let id = null;
  const elem = document.getElementById("animate");   
  pos=0; 
  clearInterval(id);
  id = setInterval(frame, 500);
  function frame() {
    elem.style.top = Math.random()*350 +"px";
    elem.style.left = Math.random()*350 +"px";
  }  
}

//questa funzione ad ora rimette il quadrato rosso nella posizione iniziale per 1 frame, ma non arresta ancora il movimento casuale della funzione myMove
function Pause() {
  let id = null;
  const elem = document.getElementById("animate");   
  pos=0;  
  elem.style.top = pos + "px"; 
  elem.style.left = pos + "px"; 
  clearInterval(id);
  }

//questa funzione calcola il punteggio ottenuto dal giocatore
function myPoints(){
  // Get the value of the input field with id="numb"
  let x = 0;
  // If x is Not a Number or less than one or greater than 10
  let text;
  text = "x";
  x++;
 
  document.getElementById("demo").innerHTML = text;
}