# Prove2quadrati

A Pen created on CodePen.io. Original URL: [https://codepen.io/DarioCellai1989/pen/jOZKQaJ](https://codepen.io/DarioCellai1989/pen/jOZKQaJ).

prove per capire come funziona codepen