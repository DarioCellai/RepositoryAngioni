let posO = 0;
let posV = 0;
function myMoveOr() {
  const elem = document.getElementById("animate");   
  posO+=10; 
  elem.style.left = posO + "px"; 
  }
function myMoveVert() {
  const elem = document.getElementById("animate");   
  posV+=10; 
  elem.style.top = posV + "px"; 
  }
  
function Reset() {
  const elem = document.getElementById("animate");   
  posV=0; 
  posO=0; 
  elem.style.top = posV + "px"; 
  elem.style.left = posO + "px"; 
  }


function myMove() {
  let id = null;
  const elem = document.getElementById("animate");  
  posV=0; 
  posO=0; 
  clearInterval(id);
  id = setInterval(frame, 5);
  function frame() {
    if (posV == 350||posO ==350) {
      clearInterval(id);
    } else {
      posV++ && posO++; 
      elem.style.top = posV + "px"; 
      elem.style.left = posO + "px"; 
    }
  /*elem.style.top = posV + "px"; 
  elem.style.left = posO + "px";
      
    clearInterval(id);
  id = setInterval(randomFrame, 500);
  function randomFrame() {
      function getRndInteger(min, max) {
  return Math.floor(Math.random() * (max - min) ) + min;
}*/

  }
}
/*function myMove() {
  let id = null;
  const elem = document.getElementById("animate");   
  let pos = 0;
  clearInterval(id);
  id = setInterval(frame, 5);
  function frame() {
    if (pos == 350) {
      clearInterval(id);
    } else {
      pos++; 
      elem.style.top = pos + "px"; 
      elem.style.left = pos + "px"; 
    }
  }
}*/