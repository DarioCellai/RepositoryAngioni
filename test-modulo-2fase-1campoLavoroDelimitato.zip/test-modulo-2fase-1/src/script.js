 var posO=0;
 var posV=0;
//var id = null;
function myMove() {
  const elem = document.getElementById("animate");
 
 // clearInterval(id);
  //id = setInterval(frame,100);
    if(posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
   // function frame(){

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
     

     
      
   //clearInterval(id);
   
 /* 
     
    */
  //}

function Reset(){
 const elem = document.getElementById("animate");
  posV=0;
  posO=0;
  elem.style.top = posV + 'px'; 
  elem.style.left = posO + 'px';
}
