# Test Modulo 2 - fase 3/1 Modificato

A Pen created on CodePen.io. Original URL: [https://codepen.io/DarioCellai1989/pen/poLweVL](https://codepen.io/DarioCellai1989/pen/poLweVL).

