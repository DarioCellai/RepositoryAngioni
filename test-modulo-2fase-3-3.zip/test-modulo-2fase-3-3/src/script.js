 var posO=0;
 var posV=0;
//var id = null;
function myMove() {
  const elem = document.getElementById("animate");
 
    if(posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}   

function Move11() {
  const elem = document.getElementById("animate");
 
    if(posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=1; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
   
function Reset(){
 const elem = document.getElementById("animate");
  posV=0;
  posO=0;
  elem.style.top = posV + 'px'; 
  elem.style.left = posO + 'px';
}

function Move1() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=2; 
    posV+=(-2); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move2() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=(-2); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move3() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-2); 
    posV+=(-2); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move4() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=2; 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move6() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-2); 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move7() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=2; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move8() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move9() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-2); 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
