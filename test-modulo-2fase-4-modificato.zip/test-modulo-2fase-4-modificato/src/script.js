var posO=34;
 var posV=34;
//var id = null;
//funzioni del quadratino rosso centrale
//movimento associato a click su tasto Move!
function myMove() {
  const elem = document.getElementById("animate");
 
    if( posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=1; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
  DanceRed();
}   
//movimento associato a click su tasti del quadrato rosso senza segni
function Move00() {
  const elem = document.getElementById("animate");
 
    if( posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=1; 
    posV+=1; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}     
//riporta il quadrato rosso alla posizione di partenza   
function Reset(){
 const elem = document.getElementById("animate");
  posV=34;
  posO=34;
  elem.style.top = posV + 'px'; 
  elem.style.left = posO + 'px';
   DanceRed();
}
//ferma il quadrato rosso nella posizione del momento
function Stop(){
 const elem = document.getElementById("animate");
  clearInterval(id);
 
  elem.style.top =  'px'; 
  elem.style.left =  'px';
   DanceRed();
}
//animazione casuale
function Randoom() {
  const elem = document.getElementById("animate");
 let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval);
  function frame() {{
      if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    
    posO+=Math.floor((Math.random()* 3) - 1); 
    posV+=Math.floor((Math.random()* 3) - 1);
      } 
    
    else{if (posO <34){
        posO+=2; 
        }
         if (posV <34){
        posV+=2; 
        }
        if (posO >327){
        posO-=2; 
        }
         if (posV >327){
        posO-=2; 
        }
        
    } 
        elem.style.top = posV + 'px'; 
        elem.style.left = posO + 'px';
        DanceRed();
        } 
    }  
}   
//////////////////////////////
//movimento associato al tasto 1   
function Move1() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+= 10; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
  //movimento associato al tasto 2   
function Move2() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=0; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}  
//movimento associato al tasto 3   
function Move3() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=(-10); 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//movimento associato al tasto 4   
function Move4() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=10; 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}     
    //movimento associato al tasto 6 
function Move6() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=(-10); 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
   

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
  DanceRed();
}
//movimento associato al tasto 7   
function Move7() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+= 10; 
    posV+= 10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//movimento associato al tasto 8   
function Move8() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+=0; 
    posV+=10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}
//movimento associato al tasto 9   
function Move9() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 327 && posV <= 327){
    posO+= (-10); 
    posV+= 10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//funzioni di collegamento del quadrato rosso centrale coi quadrati rossi della cornice; la numerazione fa riferimento a Move (mossa) del quadrato rosso (1) ed in particolare di un quadratino, nella posizione sulla tastiera numerica che porta lo stesso numero (esempio, quadrato in posizione 2 in basso o 6 a destra)
function DanceRed(){
  Move11();
  Move12();
  Move13();
  Move14();
  Move16();
  Move17();
  Move18();
  Move19();
}

function Move11() {
  const elem1 = document.getElementById("animate1");
  const elem = document.getElementById("animate");
  var posO1= posO - 33;
  var posV1= posV + 33;
elem1.style.top = posV1 + 'px'; 
    elem1.style.left = posO1 + 'px';
}

function Move12() {
  const elem2 = document.getElementById("animate2");
  const elem = document.getElementById("animate");
  var posO2= posO ;
  var posV2= posV + 33;
elem2.style.top = posV2 + 'px'; 
    elem2.style.left = posO2 + 'px';
}
function Move13() {
  const elem3 = document.getElementById("animate3");
  const elem = document.getElementById("animate");
  var posO3= posO + 33;
  var posV3= posV + 33;
elem3.style.top = posV3 + 'px'; 
    elem3.style.left = posO3 + 'px';
}
function Move14() {
  const elem4 = document.getElementById("animate4");
  const elem = document.getElementById("animate");
  var posO4= posO - 33;
  var posV4= posV ;
elem4.style.top = posV4 + 'px'; 
    elem4.style.left = posO4 + 'px';
}
function Move16() {
  const elem6 = document.getElementById("animate6");
  const elem = document.getElementById("animate");
  var posO6= posO + 33;
  var posV6= posV;
elem6.style.top = posV6 + 'px'; 
    elem6.style.left = posO6 + 'px';
}
function Move17() {
  const elem7 = document.getElementById("animate7");
  const elem = document.getElementById("animate");
  var posO7= posO - 33;
  var posV7= posV - 33;
elem7.style.top = posV7 + 'px'; 
    elem7.style.left = posO7 + 'px';
}
function Move18() {
  const elem8 = document.getElementById("animate8");
  const elem = document.getElementById("animate");
  var posO8= posO ;
  var posV8= posV - 33;
elem8.style.top = posV8 + 'px'; 
    elem8.style.left = posO8 + 'px';
}
function Move19() {
  const elem9 = document.getElementById("animate9");
  const elem = document.getElementById("animate");
  var posO9= posO + 33;
  var posV9= posV - 33;
elem9.style.top = posV9 + 'px'; 
    elem9.style.left = posO9 + 'px';
}
