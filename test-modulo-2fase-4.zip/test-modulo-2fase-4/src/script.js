

var posO=0;
 var posV=0;
var posAO=0;
var posAV=0;
var id = null;

function Move5() {
  const elem = document.getElementById("animate");
 let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval);
  function frame() {
      if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    
    posO+=Math.floor((Math.random()* 3) - 1); 
    posV+=Math.floor((Math.random()* 3) - 1); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
        posO-=posO; 
        posV-=posV; 
        elem.style.top = posV + 'px'; 
        elem.style.left = posO + 'px';
  
        } 
    } 
}   
/*//class Walker -> progetto da visualizzare
class Walker {
  constructor(elemParameter) {
    this.elem = elemParameter;
    this.x = 1;
    this.y = 1;
  } //costruttore setta posizione iniziale del quadrato
  //walker.step(); //sposta l'oggetto walker
  step() {
    let incrementox;
    let incrementoy;
    incrementox = Math.floor((Math.random()* 3) - 1);
    incrementoy = Math.floor((Math.random()* 3) - 1);
    this.y = this.y + incrementoy;
    this.x = this.x + incrementox;
    if (this.y < 0) {
      this.y = this.y + 350;
    }
    if (this.x < 0) {
      this.x = this.x + 350;
    }
    if (this.y > 350) {
      this.y = this.y - 350;
    }
    if (this.x > 350) {
      this.x = this.x - 350;
    }
  }
  // walker.display(); //aggiorna la posizione di walker
  display() {
    this.elem.style.top = this.y + "px";
    this.elem.style.left = this.x + "px";
  }
  // walker1.step(); //sposta l'oggetto walker1
  //walker1.display(); //aggiorna la posizione di walker1 
  walkerUpdate() {
    this.step();
    this.display();
  }
  walkerReset() {
    this.x = 1;
    this.y = 1;
    this.display();
  }
}

function frame() {
  
 
 
 
  walker.walkerUpdate();
  walker1.walkerUpdate();
}

function myMove() {
  let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval); //imposta il timer con cui chiama la funzione frame()
  }

function myStop() {
  clearInterval(id);
  walker.walkerReset(); //riporta l'oggetto walker alla posizione 1px, 1px
  walker1.walkerReset(); //riporta l'oggetto walker1 alla posizione 1px, 1px
}

let walker = new Walker(document.getElementById("animate")); //crea un nuovo oggetto (walker) appartenente alla classe Walker

let walker1 = new Walker(document.getElementById("animate1")); //crea un nuovo oggetto (walker1) appartenente alla classe Walker
  */
function myMove() {
  const elem = document.getElementById("animate");
 
    if(posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}   


  

function Move11() {
  const elem = document.getElementById("animate");
 
    if(posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=1; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
   
function Reset(){
 const elem = document.getElementById("animate");
  clearInterval(id);
  posV=0;
  posO=0;
  elem.style.top = posV + 'px'; 
  elem.style.left = posO + 'px';
}

function Stop(){
 const elem = document.getElementById("animate");
  clearInterval(id);
 
  elem.style.top =  'px'; 
  elem.style.left =  'px';
}

function Move1() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move2() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move3() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move4() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move6() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move7() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move8() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
function Move9() {
  const elem = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
}     
