var posO=34;
 var posV=34;
//var id = null;
//funzioni del quadratino rosso centrale
//movimento associato a click su tasto Move!
function myMove() {
  const elem = document.getElementById("animate");
 
    if( posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=1; 
    posV+=2; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
  DanceRed();
}   
//movimento associato a click su tasti del quadrato rosso senza segni
function Move00() {
  const elem = document.getElementById("animate");
 
    if( posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=1; 
    posV+=1; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}     
//riporta il quadrato rosso alla posizione di partenza   
function Reset(){
 const elem = document.getElementById("animate");
   clearInterval(id);
  posV=34;
  posO=34;
  elem.style.top = posV + 'px'; 
  elem.style.left = posO + 'px';
   DanceRed();
}
//ferma il quadrato rosso nella posizione del momento
function Stop(){
 const elem = document.getElementById("animate");
  clearInterval(id);
 
  elem.style.top =  'px'; 
  elem.style.left =  'px';
   DanceRed();
}
//animazione casuale
function Randoom() {
  const elem = document.getElementById("animate");
 let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval);
  function frame() {{
      if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    
    posO+=Math.floor((Math.random()* 3) - 1); 
    posV+=Math.floor((Math.random()* 3) - 1);
      } 
    
    else{if (posO <34){
        posO+=2; 
        }
         if (posV <34){
        posV+=2; 
        }
        if (posO >334){
        posO-=2; 
        }
         if (posV >334){
        posV-=2; 
        }
        
    } 
        elem.style.top = posV + 'px'; 
        elem.style.left = posO + 'px';
        DanceRed();
        } 
    }  
}   
//////////////////////////////
//movimento associato al tasto 1   
function Move1() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+= 10; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
  //movimento associato al tasto 2   
function Move2() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=0; 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}  
//movimento associato al tasto 3   
function Move3() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=(-10); 
    posV+=(-10); 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//movimento associato al tasto 4   
function Move4() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=10; 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}     
    //movimento associato al tasto 6 
function Move6() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=(-10); 
    posV+=0; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
   

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
  DanceRed();
}
//movimento associato al tasto 7   
function Move7() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+= 10; 
    posV+= 10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//movimento associato al tasto 8   
function Move8() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+=0; 
    posV+=10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}
//movimento associato al tasto 9   
function Move9() {
  const elem = document.getElementById("animate");
 
    if(posO >=34 && posV >=34 && posO <= 334 && posV <= 334){
    posO+= (-10); 
    posV+= 10; 
    elem.style.top = posV + 'px'; 
    elem.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem.style.top =  posV +'px';
          elem.style.left =  posO +'px';
        } 
   DanceRed();
}    
//funzioni di collegamento del quadrato rosso centrale coi quadrati rossi della cornice; la numerazione fa riferimento a Move (mossa) del quadrato rosso (1) ed in particolare di un quadratino, nella posizione sulla tastiera numerica che porta lo stesso numero (esempio, quadrato in posizione 2 in basso o 6 a destra)
function DanceRed(){
  Move11();
  Move12();
  Move13();
  Move14();
  Move16();
  Move17();
  Move18();
  Move19();
EndGame();
}

function Move11() {
  const elem1 = document.getElementById("animate1");
  const elem = document.getElementById("animate");
  var posO1= posO - 33;
  var posV1= posV + 33;
elem1.style.top = posV1 + 'px'; 
    elem1.style.left = posO1 + 'px';
EndGame();
}

function Move12() {
  const elem2 = document.getElementById("animate2");
  const elem = document.getElementById("animate");
  var posO2= posO ;
  var posV2= posV + 33;
elem2.style.top = posV2 + 'px'; 
    elem2.style.left = posO2 + 'px';
EndGame();
}
function Move13() {
  const elem3 = document.getElementById("animate3");
  const elem = document.getElementById("animate");
  var posO3= posO + 33;
  var posV3= posV + 33;
elem3.style.top = posV3 + 'px'; 
    elem3.style.left = posO3 + 'px';
EndGame();
}
function Move14() {
  const elem4 = document.getElementById("animate4");
  const elem = document.getElementById("animate");
  var posO4= posO - 33;
  var posV4= posV ;
elem4.style.top = posV4 + 'px'; 
    elem4.style.left = posO4 + 'px';
EndGame();
}
function Move16() {
  const elem6 = document.getElementById("animate6");
  const elem = document.getElementById("animate");
  var posO6= posO + 33;
  var posV6= posV;
elem6.style.top = posV6 + 'px'; 
    elem6.style.left = posO6 + 'px';
EndGame();
}
function Move17() {
  const elem7 = document.getElementById("animate7");
  const elem = document.getElementById("animate");
  var posO7= posO - 33;
  var posV7= posV - 33;
elem7.style.top = posV7 + 'px'; 
    elem7.style.left = posO7 + 'px';
EndGame();
}
function Move18() {
  const elem8 = document.getElementById("animate8");
  const elem = document.getElementById("animate");
  var posO8= posO ;
  var posV8= posV - 33;
elem8.style.top = posV8 + 'px'; 
    elem8.style.left = posO8 + 'px';
EndGame();
}
function Move19() {
  const elem9 = document.getElementById("animate9");
  const elem = document.getElementById("animate");
  var posO9= posO + 33;
  var posV9= posV - 33;
elem9.style.top = posV9 + 'px'; 
    elem9.style.left = posO9 + 'px';
EndGame();
}

//////////////////////////////////////
//quadrato blu
/////////////////////////////////////
var posOb=333;
 var posVb=333;
//var id = null;
//funzioni del quadratino rosso centrale
//movimento associato a click su tasto Move!
function myMoveBlue() {
  const elemb = document.getElementById("animate20");
 
    if( posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=1; 
    posVb+=2; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
  DanceBlue();
}   
//movimento associato a click su tasti del quadrato blu senza segni
function Move000() {
  const elemb = document.getElementById("animate20");
 
    if( posOb >=34 && posVb >=34 && posOb <= 334 && posV <= 334){
    posOb+=1; 
    posVb+=1; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}     
//riporta il quadrato blu alla posizione di partenza   
function ResetBlue(){
 const elemb = document.getElementById("animate20");
   clearInterval(id);
  posVb=334;
  posOb=334;
  elemb.style.top = posVb + 'px'; 
  elemb.style.left = posOb + 'px';
   DanceBlue();
}
//ferma il quadrato blu nella posizione del momento
function StopBlue(){
 const elemb = document.getElementById("animate20");
  clearInterval(id);
 
  elemb.style.top =  'px'; 
  elemb.style.left =  'px';
   DanceBlue();
}
//animazione casuale
function RandoomBlue() {
  const elemb = document.getElementById("animate20");
 let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval);
  function frame() {{
      if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    
    posOb+=Math.floor((Math.random()* 3) - 1); 
    posVb+=Math.floor((Math.random()* 3) - 1);
      } 
    
    else{if (posOb <34){
        posOb+=2; 
        }
         if (posVb <34){
        posVb+=2; 
        }
        if (posOb >334){
        posOb-=2; 
        }
         if (posVb >334){
        posVb-=2; 
        }
        
    } 
        elemb.style.top = posVb + 'px'; 
        elemb.style.left = posOb + 'px';
        DanceBlue();
        } 
    }  
}   
//////////////////////////////
//movimento associato al tasto 1   
function Move21() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+= 10; 
    posVb+=(-10); 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posV +'px';
          elemb.style.left =  posO +'px';
        } 
   DanceBlue();
}    
  //movimento associato al tasto 2   
function Move22() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=0; 
    posVb+=(-10); 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}  
//movimento associato al tasto 3   
function Move23() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=(-10); 
    posVb+=(-10); 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}    
//movimento associato al tasto 4   
function Move24() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=10; 
    posVb+=0; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}     
    //movimento associato al tasto 6 
function Move26() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=(-10); 
    posVb+=0; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
   

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
  DanceBlue();
}
//movimento associato al tasto 7   
function Move27() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+= 10; 
    posVb+= 10; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}    
//movimento associato al tasto 8   
function Move28() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+=0; 
    posVb+=10; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}
//movimento associato al tasto 9   
function Move29() {
  const elemb = document.getElementById("animate20");
 
    if(posOb >=34 && posVb >=34 && posOb <= 334 && posVb <= 334){
    posOb+= (-10); 
    posVb+= 10; 
    elemb.style.top = posVb + 'px'; 
    elemb.style.left = posOb + 'px';
    }else{
  

          posOb+=0;
          posVb+=0;
          elemb.style.top =  posVb +'px';
          elemb.style.left =  posOb +'px';
        } 
   DanceBlue();
}    
//funzioni di collegamento del quadrato rosso centrale coi quadrati rossi della cornice; la numerazione fa riferimento a Move (mossa) del quadrato rosso (1) ed in particolare di un quadratino, nella posizione sulla tastiera numerica che porta lo stesso numero (esempio, quadrato in posizione 2 in basso o 6 a destra)
function DanceBlue(){
  Move211();
  Move212();
  Move213();
  Move214();
  Move216();
  Move217();
  Move218();
  Move219();
EndGame();
}

function Move211() {
  const elem1 = document.getElementById("animate21");
  const elem = document.getElementById("animate20");
  var posOb1= posOb - 33;
  var posVb1= posVb + 33;
elem1.style.top = posVb1 + 'px'; 
    elem1.style.left = posOb1 + 'px';
EndGame();
}

function Move212() {
  const elem2 = document.getElementById("animate22");
  const elem = document.getElementById("animate20");
  var posOb2= posOb ;
  var posVb2= posVb + 33;
elem2.style.top = posVb2 + 'px'; 
    elem2.style.left = posOb2 + 'px';
EndGame();
}
function Move213() {
  const elem3 = document.getElementById("animate23");
  const elem = document.getElementById("animate20");
  var posOb3= posOb + 33;
  var posVb3= posVb + 33;
elem3.style.top = posVb3 + 'px'; 
    elem3.style.left = posOb3 + 'px';
EndGame();
}
function Move214() {
  const elem4 = document.getElementById("animate24");
  const elem = document.getElementById("animate20");
  var posOb4= posOb - 33;
  var posVb4= posVb ;
elem4.style.top = posVb4 + 'px'; 
    elem4.style.left = posOb4 + 'px';
EndGame();
}
function Move216() {
  const elem6 = document.getElementById("animate26");
  const elem = document.getElementById("animate20");
  var posOb6= posOb + 33;
  var posVb6= posVb;
elem6.style.top = posVb6 + 'px'; 
    elem6.style.left = posOb6 + 'px';
EndGame();
}
function Move217() {
  const elem7 = document.getElementById("animate27");
  const elem = document.getElementById("animate20");
  var posOb7= posOb - 33;
  var posVb7= posVb - 33;
elem7.style.top = posVb7 + 'px'; 
    elem7.style.left = posOb7 + 'px';
EndGame();
}
function Move218() {
  const elem8 = document.getElementById("animate28");
  const elem = document.getElementById("animate20");
  var posOb8= posOb ;
  var posVb8= posVb - 33;
elem8.style.top = posVb8 + 'px'; 
    elem8.style.left = posOb8 + 'px';
EndGame();
}
function Move219() {
  const elem9 = document.getElementById("animate29");
  const elem = document.getElementById("animate20");
  var posOb9= posOb + 33;
  var posVb9= posVb - 33;
elem9.style.top = posVb9 + 'px'; 
    elem9.style.left = posOb9 + 'px';
EndGame();
}

////////////////////////////
//condizione vittoria non funzionante

function EndGame(){

     const elem = document.getElementById("animate");
     const elem1 = document.getElementById("animate20");
     if (elem.style.top  == elem1.style.top  && elem.style.left == elem1.style.left){
        
       alert("Il giocatore che ha mosso per ultimo ha vinto!");
      Reset();
     ResetBlue();
    
     }else{}
 
    
  
}