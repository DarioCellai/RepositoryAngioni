//duplicare le funzioni per il nuovo quadrato
var posO=0;
 var posV=0;

var id = null;

function Move5() {
  const elem1 = document.getElementById("animate");
 let interval = 5; //imposta l'intervallo
  id = setInterval(frame, interval);
  function frame() {
      if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    
    posO+=Math.floor((Math.random()* 3) - 1); 
    posV+=Math.floor((Math.random()* 3) - 1); 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
        posO-=posO; 
        posV-=posV; 
        elem1.style.top = posV + 'px'; 
        elem1.style.left = posO + 'px';
  
        } 
    }  EndGame();
}   

function myMove() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=2; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}   


  

function Move11() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=1; 
    posV+=1; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
   
function Reset(){
 const elem1 = document.getElementById("animate");
  clearInterval(id);
  posV=0;
  posO=0;
  elem1.style.top = posV + 'px'; 
  elem1.style.left = posO + 'px';
  EndGame();
}

function Stop(){
 const elem1 = document.getElementById("animate");
  clearInterval(id);
  elem1.style.top =  'px'; 
  elem1.style.left =  'px';
   EndGame();
}

function Move1() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=(-10); 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move2() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=(-10); 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move3() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=(-10); 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move4() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=0; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move6() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=0; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move7() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=10; 
    posV+=10; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move8() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=0; 
    posV+=10; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
function Move9() {
  const elem1 = document.getElementById("animate");
 
    if(posO >=0 && posV >=0 && posO <= 350 && posV <= 350){
    posO+=(-10); 
    posV+=10; 
    elem1.style.top = posV + 'px'; 
    elem1.style.left = posO + 'px';
    }else{
  

          posO+=0;
          posV+=0;
          elem1.style.top =  posV +'px';
          elem1.style.left =  posO +'px';
        }  EndGame();
}     
/////////////////////////////
var pos2O=0;
 var pos2V=0;
/*'py' =  349 +'px';
'py' =  349 +'px';*/
var id2 = null;


function Move25() {
  const elem2 = document.getElementById("animate1");
 let interval = 5; //imposta l'intervallo
  id2 = setInterval(frame, interval);
  function frame() {
      if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    
    pos2O+=Math.floor((Math.random()* 3) - 1); 
    pos2V+=Math.floor((Math.random()* 3) - 1); 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
        pos2O-=pos2O; 
        pos2V-=pos2V; 
        elem2.style.top = pos2V + 'px'; 
        elem2.style.left = pos2O + 'px';
  
        } 
    }  EndGame();
}   

function myMoveBlue() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 &&  pos2O <= 350 && pos2V <= 350){
    pos2O+=1; 
    pos2V+=2; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}   


  

function Move111() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 &&  pos2O <= 350 && pos2V <= 350){
    pos2O+=1; 
    pos2V+=1; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
   
function ResetBlue(){
 const elem2 = document.getElementById("animate1");
  clearInterval(id2);
  pos2V=349;
  pos2O=349;
  elem2.style.top = pos2V + 'px'; 
  elem2.style.left = pos2O + 'px';
   EndGame();
}

function StopBlue(){
 const elem2 = document.getElementById("animate1");
  clearInterval(id2);
 
  elem2.style.top =  'px'; 
  elem2.style.left =  'px';
   EndGame();
}

function Move21() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=10; 
    pos2V+=(-10); 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move22() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=0; 
    pos2V+=(-10); 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move23() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=(-10); 
    pos2V+=(-10); 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  posV +'px';
          elem2.style.left =  posO +'px';
        }  EndGame();
}     
function Move24() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=10; 
    pos2V+=0; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move26() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=(-10); 
    pos2V+=0; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move27() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=10; 
    pos2V+=10; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move28() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=0; 
    pos2V+=10; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
function Move29() {
  const elem2 = document.getElementById("animate1");
 
    if(pos2O >=0 && pos2V >=0 && pos2O <= 350 && pos2V <= 350){
    pos2O+=(-10); 
    pos2V+=10; 
    elem2.style.top = pos2V + 'px'; 
    elem2.style.left = pos2O + 'px';
    }else{
  

          pos2O+=0;
          pos2V+=0;
          elem2.style.top =  pos2V +'px';
          elem2.style.left =  pos2O +'px';
        }  EndGame();
}     
////////////////////////////


function EndGame(){

     const elem1 = document.getElementById("animate");
     const elem2 = document.getElementById("animate1");
     if (elem1.style.top == elem2.style.top && elem1.style.left == elem2.style.left){
        
       alert("Il giocatore che ha mosso per ultimo ha vinto!");
      Reset();
     ResetBlue();
    
     }else{}
 
    
  
}